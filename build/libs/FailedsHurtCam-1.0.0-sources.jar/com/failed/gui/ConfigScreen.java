package com.failed.gui;

import com.failed.config.Config;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {
    private final class_437 parent;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("FailedsHurtCam Config"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Disable HurtCam: " + (Config.disableHurtCam ? "ON" : "OFF")),
            button -> {
                Config.disableHurtCam = !Config.disableHurtCam;
                button.method_25355(class_2561.method_43470("Disable HurtCam: " + (Config.disableHurtCam ? "ON" : "OFF")));
                Config.save();
            }
        ).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2 - 20, 200, 20).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Done"),
            button -> this.field_22787.method_1507(this.parent)
        ).method_46434(this.field_22789 / 2 - 100, this.field_22790 / 2 + 10, 200, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        super.method_25394(graphics, mouseX, mouseY, delta);
        graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
    }
}
